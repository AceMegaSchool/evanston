self.assetsManifest = {
  "version": "XKmXcvjH",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-wM8xoXP2L+CqUYHe3TIpJrGysLtdZS34D5Y9xx83QaM=",
      "url": "Evanston.styles.css"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-3FM/mjas9rQiq2CY+FQPy1Pe1iCLSx/qZltQxK4dcuQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-Qf9/gSPxTxchB08Wi5WXxjPqw2IQvnyVUW27s7cwoUo=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-aTiMfbTyZZ5fbOa7Annsl9BgMlZAJi6Oxz59HRWzWBY=",
      "url": "_framework/Evanston.hy94xryoit.wasm"
    },
    {
      "hash": "sha256-4qCjCkeMkrC39fhhzGK6jZVM+CSQXhBgirZfr1DM/6I=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.yv2qi7o6jg.wasm"
    },
    {
      "hash": "sha256-+5+/1obWKmNeB9zuGBeA2beO5qKtdJKqtqHxaoMFDzE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.fj8j66h5p2.wasm"
    },
    {
      "hash": "sha256-1bZXAq7xg/K+UZT3zZxmJHp4UKNJQBP+2ny+/lGkyHo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.rwpg67y8a3.wasm"
    },
    {
      "hash": "sha256-Zf0UUqPjcNPCclGVKFSX+wTUQ4UKcCBxqan0Ipo7CXQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.fj6q3rv5qy.wasm"
    },
    {
      "hash": "sha256-3ADlF4CLU1Q+dQbj0MnPVnEJPiA4q4Jv5xxmiGEvBks=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.85u9862gz3.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-fN4AyqImDQ+h3H7tFeF4ZSkjIHJ7qWgbKL217x6P53s=",
      "url": "_framework/Microsoft.Extensions.Configuration.cyz6aj3end.wasm"
    },
    {
      "hash": "sha256-dxXtIbV5+SsgGXRNGq6r/wDdE1JwNabSShZGXs16rTY=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.7socdk9i65.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-63CoZs2v8kUdc0XLRhWY4gt+HvG+sALt8MhboCYTjp0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.bkdtnkwhhv.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-iCJ7MgEDmi8gJJ4kr+vCM0UW+W51Th0XAwRG1vPU9Ak=",
      "url": "_framework/Microsoft.Extensions.Options.sv9qmqvsmm.wasm"
    },
    {
      "hash": "sha256-WXYpl64HUqc9+prJOz6dOEVvB8PFJhTdfqUMB3ZGRGA=",
      "url": "_framework/Microsoft.Extensions.Primitives.5pxr7nzxwe.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-aGKgw+oy/q1c/wB6pq6Jwqo6y8C6P1ht0dSWD2Litwc=",
      "url": "_framework/Microsoft.JSInterop.g6svuh4n00.wasm"
    },
    {
      "hash": "sha256-rSwmrShqx1KCrKoN7JCxp6MZuRjtBriQdttiVW6W0xM=",
      "url": "_framework/MudBlazor.fl9bib3t9n.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-ZwToh0+onnsuEEi4ISoq7tGM9S9l8NmpDtywTW7VASI=",
      "url": "_framework/Riok.Mapperly.Abstractions.v2oa0z4fia.wasm"
    },
    {
      "hash": "sha256-crbTUDAwjV33awtJpY1O3pB3dmDUep9pkFcZQ0Piap8=",
      "url": "_framework/System.Collections.Concurrent.yjwfvapqpq.wasm"
    },
    {
      "hash": "sha256-Tt9gFH0IeBKovxPeqnJ2rH3UGa5Du+IDj5hhZjxL/R8=",
      "url": "_framework/System.Collections.Immutable.6387w7a7pa.wasm"
    },
    {
      "hash": "sha256-C5lqsHBkjIIuGfClfiFnsOkE7ELFFUyHBSaH7YpaUrE=",
      "url": "_framework/System.Collections.zyelq8u0gu.wasm"
    },
    {
      "hash": "sha256-/TUgJRG3EZB5Bcfo9BEFJ61DIJLAJRTXeLYB1vnMd1Q=",
      "url": "_framework/System.ComponentModel.5y3o4qq5pj.wasm"
    },
    {
      "hash": "sha256-OEUiONvTvRl0zXaRpOxe8N1bZm9G8n1a8O1MU0CuiIs=",
      "url": "_framework/System.ComponentModel.Annotations.c3oteuai4j.wasm"
    },
    {
      "hash": "sha256-jDB4ONn+ytOxP9ATQtYg8+Z+2V3rMH1Ci9k8CPo9Y8k=",
      "url": "_framework/System.ComponentModel.Primitives.g5fj0nkchn.wasm"
    },
    {
      "hash": "sha256-OLm71vFejrfS7tuHwbQIrbPJJFFvqFC1eM7SgYnxTfA=",
      "url": "_framework/System.Console.gi7zmwq5sa.wasm"
    },
    {
      "hash": "sha256-WTIaO9jlWp1gc+GNRs9kw954huS0bEbief4H1pIS9wY=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.dzuuublwen.wasm"
    },
    {
      "hash": "sha256-ltKNH6AL0soduarPfzy6T90WE3rPgr3GhVxWtFvIglk=",
      "url": "_framework/System.IO.Pipelines.mslxeuynkl.wasm"
    },
    {
      "hash": "sha256-jDONNFhjThQ6OrmCa/FWqcCCYE//1Ckf+KMYJWYfqTs=",
      "url": "_framework/System.Linq.Expressions.4mzxxspj2t.wasm"
    },
    {
      "hash": "sha256-KK79OqFyD+6fybRa4zudWl9mRUqcbnD9obcnuA21Diw=",
      "url": "_framework/System.Linq.gamo7d1o2z.wasm"
    },
    {
      "hash": "sha256-cogZ93o17jQq3v9gfbCiEi3NkOEbeJgaWUnNTLgMIfA=",
      "url": "_framework/System.Memory.6vh06ia9tj.wasm"
    },
    {
      "hash": "sha256-aM5lnXSVHudXZdVfGzEOyfKs+OC7OweUO2Ke9Uy8tqo=",
      "url": "_framework/System.Net.Http.Json.k138522ykx.wasm"
    },
    {
      "hash": "sha256-NzG4+in8O5kCvuyryU6QEgE/GxkcixhymgfBFOyYFss=",
      "url": "_framework/System.Net.Http.jljgerlo0t.wasm"
    },
    {
      "hash": "sha256-DqsumNiS0cF1FXZ5sSRsGHgAG63fChKhelkEA9f6A50=",
      "url": "_framework/System.Net.Primitives.yjcmep7m7h.wasm"
    },
    {
      "hash": "sha256-jrs/nF0u/Oq5uLawDMoFZyTO1BE0QDgP8Atecle5vGo=",
      "url": "_framework/System.Private.CoreLib.qyhe2gv29g.wasm"
    },
    {
      "hash": "sha256-cCgEovvo9julLszFFEuF6Zrtpg0ZQ7lKt65alEFAPgA=",
      "url": "_framework/System.Private.Uri.8e94na7ibn.wasm"
    },
    {
      "hash": "sha256-5RR7XKA3QFwZn4hAQexF4URZllPm3lVU56uOqy2Fn1I=",
      "url": "_framework/System.Runtime.5k5vbjd8fv.wasm"
    },
    {
      "hash": "sha256-5X6FWiZE4NSx4s9iNjfVim2lWQpcbVIsorx1vB6lyno=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f7txb1es0b.wasm"
    },
    {
      "hash": "sha256-nowVPzdhrYNVwBj7BFC6KceUhojJ5Gz2vZGxT0qFoSA=",
      "url": "_framework/System.Text.Encodings.Web.e8bnsydrha.wasm"
    },
    {
      "hash": "sha256-tjmp1kpBHeV4su1nBMOSJ8KCTs1sax9X5IzRpufIDfE=",
      "url": "_framework/System.Text.Json.eurbsvqrt9.wasm"
    },
    {
      "hash": "sha256-ZdpMvu3kPYs4A9mdR+aivNgio549Cwdqdca4Mgf+YHc=",
      "url": "_framework/System.Text.RegularExpressions.1d5pbaurq2.wasm"
    },
    {
      "hash": "sha256-8TOdx+WTSrBAkPVcYh/dHgxZeRNAfj3bK1p4ESYA1bo=",
      "url": "_framework/System.Threading.92ez24v1xd.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-59JlDkXENRRlWHym/v7bO4RNE7SkjjJnO6EtWZN/a20=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-PhwRIU0/hz3+M0W81BGfTF1YrwHGzc24eoVYyyQufcA=",
      "url": "_framework/dotnet.native.i8trbb6f85.wasm"
    },
    {
      "hash": "sha256-F/5e/lyR+oUxW0davFx8aANjOB+Ddu6RYx2NRUxshPw=",
      "url": "_framework/dotnet.native.vmus01doem.js"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-HldBlA2xfZnDdwS0zMwZTjtH4g5fdjGQR+pVD5SZpS0=",
      "url": "_framework/netstandard.aydpa3qboo.wasm"
    },
    {
      "hash": "sha256-/IihSrpj7+sP6djzQstWcuY8TuQUp00BP7yP3gqKUnE=",
      "url": "api-spec.yaml"
    },
    {
      "hash": "sha256-KI/EgfNO7REsEfmUbFLYKmsS+ulaWnjf1WYChwPXFUQ=",
      "url": "api/v1/directory.json"
    },
    {
      "hash": "sha256-jrlby8FUUwkx4V/EGMix/pkQlWcUCVUgmeoapZaZnt4=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-SZcWvi+zAZ0okdsPuQjlc/41gRDxxUnw0TOV9inEbBw=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-peGgxEoQeoBNhhayZdAj6VQcsoDWbnquQVwsodSl+bY=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-c2RN81Gti8Q0ZWR+EQg+QSjOIU3PzhnBZVaqmjm0n+0=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-CP0Ljc20/q18iF62QJASIpEIEd3yP7NdhkmHVyMzfEU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-3PxPeZmJq1O9XnCI+qcDbEh2ugqFhtRDRTJ11Zc4th0=",
      "url": "manifest.webmanifest"
    }
  ]
};
