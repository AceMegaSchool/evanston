self.assetsManifest = {
  "version": "2LSmvwi/",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-wM8xoXP2L+CqUYHe3TIpJrGysLtdZS34D5Y9xx83QaM=",
      "url": "Evanston.styles.css"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-TSgzDIY4qdWvjvfBaUSrnerVt2+FjH4cXGlPrxEz1C0=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-hylTyzoFC8Kp1f0FRqBY1LUV5GLhjEZGZbvrFnkZ1Tw=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-ckWfRmFwfSDSO/ClUGLt4bkgMp/FeGm2dDT0CtVfAww=",
      "url": "_framework/Evanston.6elt9kvlel.wasm"
    },
    {
      "hash": "sha256-GiOCli6OTYDbLmqFi0iPV15OvBYlZmkEcGq9nkcO6U8=",
      "url": "_framework/Microsoft.AspNetCore.Components.2pmkdspi3r.wasm"
    },
    {
      "hash": "sha256-BTHXkhy/9X3p+MX0/sm31OTLsBa/eASz8VZ7QmpdYzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3qh9t4or2h.wasm"
    },
    {
      "hash": "sha256-SwoMPlHS05yT2/LjqTYV4nO5fDMfNfd6qGFDDIKUa9U=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xxzncl2btm.wasm"
    },
    {
      "hash": "sha256-Y9y4a637WBoDa08GX7Qxx63oDFsCVE/4v8oZCvLkKTo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.nvr1tj7rwf.wasm"
    },
    {
      "hash": "sha256-kMkTNci+rypvlVo91GsthRNT22k4Mk2BHQPk/Up3p7M=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.s1desti5lj.wasm"
    },
    {
      "hash": "sha256-/jB8J7byRl8++Sms23uw7dTZtf4OYQ+9wprtBqLHzvg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.6ap0l7oqnx.wasm"
    },
    {
      "hash": "sha256-XKu0mIlTddgbDgKXxAt72KH1jesOUPab12Fdli15Hmw=",
      "url": "_framework/Microsoft.Extensions.Configuration.wzhhqnelnl.wasm"
    },
    {
      "hash": "sha256-v4hD5+W3siiWlZavRp7Dzz32bawaxMMA1YFjWh6pjmU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.lb2ew916e7.wasm"
    },
    {
      "hash": "sha256-t+RV090mInmcuQIlc498uXnF8wtK1MRNcmC72iNVUZI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t7f5r90yql.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-EFH3JxUgxnGjjBDWquxBSTek6QAg8HPezdjvUVyyQMY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.o64rh0zm5x.wasm"
    },
    {
      "hash": "sha256-9x8FXDisdekP0Dbg8khNrE+Oocnngh9johtSRZyrZPk=",
      "url": "_framework/Microsoft.Extensions.Logging.bvp0h3knwz.wasm"
    },
    {
      "hash": "sha256-OVRNJEKe9y6xOoqXrWmX+sOMl/uyQiSc5cYEYWMiUY0=",
      "url": "_framework/Microsoft.Extensions.Options.7oidopj7m4.wasm"
    },
    {
      "hash": "sha256-Il7b7g4iQZWSTrBCdBft+EmS4u4r3VgzpqSIb4bfvTI=",
      "url": "_framework/Microsoft.Extensions.Primitives.a5mjza44y9.wasm"
    },
    {
      "hash": "sha256-vScvGCGFOzwoTsy7VKfMU9uuEskXbOdWabIc80iDa9g=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.9tiedlnvko.wasm"
    },
    {
      "hash": "sha256-tnAHZ/qsh7BK04vYkkW0XreHvqPwoum98+hfS+tQY3Y=",
      "url": "_framework/Microsoft.JSInterop.eyaxz6adjz.wasm"
    },
    {
      "hash": "sha256-3qSPLk5ExzmMzodThDo8vZklCs1XuJzmtl0wR1fN/t4=",
      "url": "_framework/MudBlazor.uha88jce3h.wasm"
    },
    {
      "hash": "sha256-akqbZuRazMph7GZNcPHLIOp1mgnkjdaWZMM9Up4LPfE=",
      "url": "_framework/OneOf.yq61etxwqn.wasm"
    },
    {
      "hash": "sha256-ZwToh0+onnsuEEi4ISoq7tGM9S9l8NmpDtywTW7VASI=",
      "url": "_framework/Riok.Mapperly.Abstractions.v2oa0z4fia.wasm"
    },
    {
      "hash": "sha256-ASfZ549MNDAgU/TZmO/08g4/NjBzi4Gi++AKK3PAR/0=",
      "url": "_framework/System.Collections.5vqohe2r8i.wasm"
    },
    {
      "hash": "sha256-6HesogspTc15j/wp23QpFyCWPjFDSXIV1uM5FdX5o8E=",
      "url": "_framework/System.Collections.Concurrent.0m9xdzjofc.wasm"
    },
    {
      "hash": "sha256-TkDCGna6xanRr68E8sjV8+Hlg22LwCb9vIjfwCdcrwM=",
      "url": "_framework/System.Collections.Immutable.epm7h4xwhc.wasm"
    },
    {
      "hash": "sha256-U5Jd9oGyDhXgPZfBdkkVYJrEWAFvWO5cLdl5eBQX2p8=",
      "url": "_framework/System.ComponentModel.Annotations.dcb1q9ajig.wasm"
    },
    {
      "hash": "sha256-OBk+T+LZYPaTzOg6L7ZQ/g0T5cH58sw6i6NitZebzbg=",
      "url": "_framework/System.ComponentModel.Primitives.k9ztjr9rqp.wasm"
    },
    {
      "hash": "sha256-P2bTPhn46nReTKHreFG6K47nCeDru/fCwA+UWdaZUK4=",
      "url": "_framework/System.ComponentModel.rp2ud0tstw.wasm"
    },
    {
      "hash": "sha256-WnZlnIgKvB74lTljoYtvmCwxSxs3Uas9g/Tv7JTRGDU=",
      "url": "_framework/System.Console.mcibkdfytd.wasm"
    },
    {
      "hash": "sha256-wFAsrNvmX0wIovecw3INJkK/SmkXtqL/WM06Ce+wjHg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0ouyxo2hmc.wasm"
    },
    {
      "hash": "sha256-FBW6K4TORa24v2L639DPjf309NTGkrj0iIqiJaPqcYA=",
      "url": "_framework/System.IO.Pipelines.wn1erg3up3.wasm"
    },
    {
      "hash": "sha256-DbWsqJPNY9gbyyql4ucvfETw9OfM/h9TJ3XE8c/PbQg=",
      "url": "_framework/System.Linq.175zw0t739.wasm"
    },
    {
      "hash": "sha256-sJKAJMpZz/+Xx1u3KNJlkIa8rEzQw4S8gsmBTfl7yTM=",
      "url": "_framework/System.Linq.Expressions.ctb6ccr0t9.wasm"
    },
    {
      "hash": "sha256-z/QYwpls8A0orsj/ojT/lJJHkMbNLyxIb0u0RIJlvjc=",
      "url": "_framework/System.Memory.bp0h7ss33b.wasm"
    },
    {
      "hash": "sha256-+8UiN06er4sdngV+Z/zpRMuy3jMJlu5ihSQSrwZ/Z+Q=",
      "url": "_framework/System.Net.Http.Json.36epep2r5b.wasm"
    },
    {
      "hash": "sha256-p90OMrvofEOiMR6RzRUgq7HdTjPyoJld6Zn82POhZo8=",
      "url": "_framework/System.Net.Http.pgw807lwgj.wasm"
    },
    {
      "hash": "sha256-ugfBlS5LqkQzRBUO5HH/Axxqs3sJtDp7O2gUMNFiHIM=",
      "url": "_framework/System.Net.Primitives.i2i5lejvy5.wasm"
    },
    {
      "hash": "sha256-Flv5TEiE1TvQ7Ia0eAyluTcibFWV28EuMhK90IH9dIs=",
      "url": "_framework/System.Private.CoreLib.yyc5gpo1ng.wasm"
    },
    {
      "hash": "sha256-wsWPammKQz5yWBoI7ME5sQrm/eIfJfIX8YdtHwdjbwk=",
      "url": "_framework/System.Private.Uri.y49u0fuvxj.wasm"
    },
    {
      "hash": "sha256-dr2zPg+11BQOd27TZPxcs18PqUREGUfAtTD9nRdz7sw=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.it9v611w20.wasm"
    },
    {
      "hash": "sha256-0aNcfHkP9pOyJjyba6QAgNixIKmE3GNomopTquGkEZ8=",
      "url": "_framework/System.Runtime.n6gtxthsla.wasm"
    },
    {
      "hash": "sha256-SQ1+aS+lCxp43qhvbxWS01rhQfbvNeDSN0xyk2P9/Hc=",
      "url": "_framework/System.Text.Encodings.Web.hq94nfnuw2.wasm"
    },
    {
      "hash": "sha256-RXg4NW/20RWOi0SwvcngxPkNoHlRPoPxyCDAR0B4i5M=",
      "url": "_framework/System.Text.Json.r8wq24tfod.wasm"
    },
    {
      "hash": "sha256-Aoy4g0xVNohndV15/QhQB9u1WZupq+rx8z4DgBPHpd0=",
      "url": "_framework/System.Text.RegularExpressions.elkvmrfwlo.wasm"
    },
    {
      "hash": "sha256-qpTsdttgwFKu3sCPl9Qw0nYZISOGaHpAJFTWUzt9Xzw=",
      "url": "_framework/System.Threading.6wxzpv4ki1.wasm"
    },
    {
      "hash": "sha256-nNPyM7TP7Sp4N054o563oU6FZnHcAw8jJU3H+H0sJ0I=",
      "url": "_framework/ValueOf.ccmezia1vt.wasm"
    },
    {
      "hash": "sha256-j7UNSdj7uEI1V9QsZAeI24YNAlQwo1f8gjG+sPv8dpQ=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-N+/jRbIsqVbSKyrJpXTfko/MbGFn4mYhGgK+pW+zQ7o=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-OmBqp8n93TD9WZKH0BOW+QNBRsjVCWWRUFlP3H7Accs=",
      "url": "_framework/dotnet.native.2hyxvx1bg2.wasm"
    },
    {
      "hash": "sha256-oBjTBMWipOBGg2SmgJr4yWw7x536rMCNCZgF62kqT0s=",
      "url": "_framework/dotnet.native.g0x6c0ef2o.js"
    },
    {
      "hash": "sha256-yfXUv1l/B489E8p12JxUvxly0JvHL9CCsoZUDlfGH9c=",
      "url": "_framework/dotnet.runtime.drv0pr9n5o.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-BvvV3vgI1CrXWW5VEI8ALdzKTSYUqOhP8mlA2EOlCQA=",
      "url": "_framework/netstandard.6lg0pivi6w.wasm"
    },
    {
      "hash": "sha256-/IihSrpj7+sP6djzQstWcuY8TuQUp00BP7yP3gqKUnE=",
      "url": "api-spec.yaml"
    },
    {
      "hash": "sha256-R1c+/ngKlN5m3jWQEPxZW6Vlm2Eeo42QzJp7WYBr9iw=",
      "url": "api/v1/directory.json"
    },
    {
      "hash": "sha256-jrlby8FUUwkx4V/EGMix/pkQlWcUCVUgmeoapZaZnt4=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-SZcWvi+zAZ0okdsPuQjlc/41gRDxxUnw0TOV9inEbBw=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-peGgxEoQeoBNhhayZdAj6VQcsoDWbnquQVwsodSl+bY=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-c2RN81Gti8Q0ZWR+EQg+QSjOIU3PzhnBZVaqmjm0n+0=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-CP0Ljc20/q18iF62QJASIpEIEd3yP7NdhkmHVyMzfEU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-3PxPeZmJq1O9XnCI+qcDbEh2ugqFhtRDRTJ11Zc4th0=",
      "url": "manifest.webmanifest"
    }
  ]
};
